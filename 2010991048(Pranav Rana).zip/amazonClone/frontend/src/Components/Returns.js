import '../App.css'


function Returnit() {
    return (
        <div>
            <h2>This is under maintenance</h2>
            <h3>Sorry for the inconvenience</h3>
        </div>
    )
}

export default Returnit;